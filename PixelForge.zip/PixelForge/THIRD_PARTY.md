# PixelForge — Third-Party Components

## Qt 6

Website:
https://www.qt.io/

Source:
https://code.qt.io/

Modules used:

- Qt Core
- Qt GUI
- Qt Widgets
- Qt Test (development only)

Qt licensing:

https://www.qt.io/licensing/
https://doc.qt.io/qt-6/licensing.html

The application uses Qt dynamically when deployed
with the standard shared-library Qt distribution.

Licensing requirements must be reviewed before
commercial distribution.

## Other libraries

No additional third-party libraries are directly
required by PixelForge 0.1.