#include <QtTest>

#include "core/Document.h"

class DocumentTests : public QObject
{
    Q_OBJECT

private slots:

    void documentCreation();

    void addLayer();

    void removeLayer();

    void compositeSize();

    void layerOpacity();

    void transparentBackground();
};

void DocumentTests::documentCreation()
{
    Document document(800, 600);

    QCOMPARE(document.width(), 800);

    QCOMPARE(document.height(), 600);

    QCOMPARE(document.layerCount(), 1);
}

void DocumentTests::addLayer()
{
    Document document(800, 600);

    document.addLayer("Test Layer");

    QCOMPARE(document.layerCount(), 2);

    QCOMPARE(
        document.activeLayer()->name(),
        QString("Test Layer")
    );
}

void DocumentTests::removeLayer()
{
    Document document(800, 600);

    document.addLayer("Layer 2");

    document.removeLayer(1);

    QCOMPARE(document.layerCount(), 1);
}

void DocumentTests::compositeSize()
{
    Document document(1024, 768);

    QImage image = document.composite();

    QCOMPARE(image.width(), 1024);

    QCOMPARE(image.height(), 768);
}

void DocumentTests::layerOpacity()
{
    Document document(100, 100);

    Layer* layer = document.activeLayer();

    layer->setOpacity(0.5);

    QCOMPARE(layer->opacity(), 0.5);
}

void DocumentTests::transparentBackground()
{
    Document document(100, 100);

    QImage result = document.composite();

    QCOMPARE(
        qAlpha(result.pixel(50, 50)),
        0
    );
}

QTEST_MAIN(DocumentTests)

#include "DocumentTests.moc"