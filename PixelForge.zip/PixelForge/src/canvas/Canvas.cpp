#include "Canvas.h"

#include <QPainter>
#include <QMouseEvent>
#include <QWheelEvent>
#include <QPen>

#include <algorithm>

Canvas::Canvas(QWidget* parent)
    : QWidget(parent)
{
    setMouseTracking(true);

    setMinimumSize(400, 300);
}

void Canvas::setDocument(Document* document)
{
    m_document = document;

    update();
}

void Canvas::setTool(Tool tool)
{
    m_tool = tool;
}

void Canvas::setBrushColor(const QColor& color)
{
    m_color = color;
}

void Canvas::setBrushSize(int size)
{
    m_brushSize = std::max(1, size);
}

void Canvas::setZoom(double zoom)
{
    m_zoom = std::clamp(
        zoom,
        0.1,
        16.0
    );

    update();
}

double Canvas::zoom() const
{
    return m_zoom;
}

void Canvas::paintEvent(QPaintEvent*)
{
    QPainter painter(this);

    painter.fillRect(
        rect(),
        QColor(38, 41, 48)
    );

    if (!m_document)
    {
        return;
    }

    painter.setRenderHint(
        QPainter::SmoothPixmapTransform,
        true
    );

    QImage image = m_document->composite();

    const double scaledWidth =
        m_document->width() * m_zoom;

    const double scaledHeight =
        m_document->height() * m_zoom;

    const double x =
        (width() - scaledWidth) / 2.0;

    const double y =
        (height() - scaledHeight) / 2.0;

    QRectF target(
        x,
        y,
        scaledWidth,
        scaledHeight
    );

    painter.fillRect(
        target,
        Qt::white
    );

    painter.drawImage(
        target,
        image
    );
}

QPoint Canvas::imagePosition(
    const QPoint& widgetPosition
) const
{
    if (!m_document)
    {
        return QPoint();
    }

    const double scaledWidth =
        m_document->width() * m_zoom;

    const double scaledHeight =
        m_document->height() * m_zoom;

    const double offsetX =
        (width() - scaledWidth) / 2.0;

    const double offsetY =
        (height() - scaledHeight) / 2.0;

    const int x = static_cast<int>(
        (widgetPosition.x() - offsetX) / m_zoom
    );

    const int y = static_cast<int>(
        (widgetPosition.y() - offsetY) / m_zoom
    );

    return QPoint(x, y);
}

void Canvas::drawLine(
    const QPoint& from,
    const QPoint& to
)
{
    if (!m_document)
    {
        return;
    }

    Layer* layer = m_document->activeLayer();

    if (!layer)
    {
        return;
    }

    QPainter painter(&layer->image());

    painter.setRenderHint(
        QPainter::Antialiasing,
        true
    );

    QPen pen;

    pen.setWidth(m_brushSize);

    pen.setCapStyle(Qt::RoundCap);

    pen.setJoinStyle(Qt::RoundJoin);

    if (m_tool == Tool::Eraser)
    {
        painter.setCompositionMode(
            QPainter::CompositionMode_Clear
        );

        pen.setColor(Qt::transparent);
    }
    else
    {
        painter.setCompositionMode(
            QPainter::CompositionMode_SourceOver
        );

        pen.setColor(m_color);
    }

    painter.setPen(pen);

    painter.drawLine(from, to);

    painter.end();

    update();

    emit imageChanged();
}

void Canvas::mousePressEvent(QMouseEvent* event)
{
    if (!m_document)
    {
        return;
    }

    if (event->button() == Qt::LeftButton)
    {
        m_drawing = true;

        m_lastPoint = imagePosition(
            event->position().toPoint()
        );

        drawLine(
            m_lastPoint,
            m_lastPoint
        );
    }
}

void Canvas::mouseMoveEvent(QMouseEvent* event)
{
    if (!m_drawing)
    {
        return;
    }

    QPoint current = imagePosition(
        event->position().toPoint()
    );

    drawLine(
        m_lastPoint,
        current
    );

    m_lastPoint = current;
}

void Canvas::mouseReleaseEvent(QMouseEvent* event)
{
    if (event->button() == Qt::LeftButton)
    {
        m_drawing = false;
    }
}

void Canvas::wheelEvent(QWheelEvent* event)
{
    const double factor =
        event->angleDelta().y() > 0
        ? 1.15
        : 1.0 / 1.15;

    setZoom(m_zoom * factor);

    event->accept();
}