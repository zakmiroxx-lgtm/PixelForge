#pragma once

#include <QWidget>
#include <QColor>
#include <QPoint>

#include "core/Document.h"

class Canvas : public QWidget
{
    Q_OBJECT

public:
    enum class Tool
    {
        Brush,
        Eraser
    };

    explicit Canvas(QWidget* parent = nullptr);

    void setDocument(Document* document);

    void setTool(Tool tool);

    void setBrushColor(const QColor& color);

    void setBrushSize(int size);

    void setZoom(double zoom);

    double zoom() const;

signals:
    void imageChanged();

protected:
    void paintEvent(QPaintEvent* event) override;

    void mousePressEvent(QMouseEvent* event) override;

    void mouseMoveEvent(QMouseEvent* event) override;

    void mouseReleaseEvent(QMouseEvent* event) override;

    void wheelEvent(QWheelEvent* event) override;

private:
    QPoint imagePosition(const QPoint& widgetPosition) const;

    void drawLine(
        const QPoint& from,
        const QPoint& to
    );

    Document* m_document = nullptr;

    Tool m_tool = Tool::Brush;

    QColor m_color = Qt::black;

    int m_brushSize = 12;

    double m_zoom = 1.0;

    bool m_drawing = false;

    QPoint m_lastPoint;
};