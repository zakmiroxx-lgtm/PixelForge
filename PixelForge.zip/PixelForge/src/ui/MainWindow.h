#pragma once

#include <QMainWindow>
#include <QListWidget>
#include <QSpinBox>

#include <memory>

#include "core/Document.h"
#include "canvas/Canvas.h"

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget* parent = nullptr);

private:
    void createMenus();

    void createToolbar();

    void createLayerPanel();

    void refreshLayers();

    void newDocument();

    void openImage();

    void saveImage();

    void addLayer();

    void deleteLayer();

    void selectColor();

    void refreshTitle();

    std::unique_ptr<Document> m_document;

    Canvas* m_canvas = nullptr;

    QListWidget* m_layerList = nullptr;

    QSpinBox* m_brushSize = nullptr;

    QColor m_currentColor = Qt::black;
};