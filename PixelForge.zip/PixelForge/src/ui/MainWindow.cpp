#include "MainWindow.h"

#include <QApplication>
#include <QMenuBar>
#include <QToolBar>
#include <QDockWidget>
#include <QFileDialog>
#include <QColorDialog>
#include <QMessageBox>
#include <QInputDialog>
#include <QAction>
#include <QStatusBar>
#include <QLabel>

MainWindow::MainWindow(QWidget* parent)
    : QMainWindow(parent)
{
    resize(1280, 800);

    m_document = std::make_unique<Document>(
        1200,
        800
    );

    m_canvas = new Canvas(this);

    m_canvas->setDocument(
        m_document.get()
    );

    setCentralWidget(m_canvas);

    createMenus();

    createToolbar();

    createLayerPanel();

    refreshLayers();

    refreshTitle();

    statusBar()->showMessage(
        "PixelForge ready"
    );

    setStyleSheet(R"(
        QMainWindow {
            background-color: #252830;
        }

        QMenuBar {
            background-color: #20232a;
            color: #eeeeee;
        }

        QMenuBar::item:selected {
            background-color: #383d48;
        }

        QMenu {
            background-color: #292d36;
            color: #eeeeee;
        }

        QToolBar {
            background-color: #292d36;
            spacing: 8px;
            padding: 6px;
        }

        QDockWidget {
            color: #eeeeee;
        }

        QListWidget {
            background-color: #20232a;
            color: #eeeeee;
            border: none;
        }

        QListWidget::item:selected {
            background-color: #465d82;
        }

        QStatusBar {
            background-color: #20232a;
            color: #cccccc;
        }

        QSpinBox {
            background-color: #20232a;
            color: white;
            padding: 4px;
        }
    )");
}

void MainWindow::createMenus()
{
    QMenu* fileMenu = menuBar()->addMenu(
        "File"
    );

    QAction* newAction = fileMenu->addAction(
        "New"
    );

    QAction* openAction = fileMenu->addAction(
        "Open Image"
    );

    QAction* saveAction = fileMenu->addAction(
        "Export PNG"
    );

    newAction->setShortcut(
        QKeySequence::New
    );

    openAction->setShortcut(
        QKeySequence::Open
    );

    saveAction->setShortcut(
        QKeySequence::Save
    );

    connect(
        newAction,
        &QAction::triggered,
        this,
        &MainWindow::newDocument
    );

    connect(
        openAction,
        &QAction::triggered,
        this,
        &MainWindow::openImage
    );

    connect(
        saveAction,
        &QAction::triggered,
        this,
        &MainWindow::saveImage
    );

    QMenu* layerMenu = menuBar()->addMenu(
        "Layers"
    );

    QAction* addAction = layerMenu->addAction(
        "Add Layer"
    );

    QAction* deleteAction = layerMenu->addAction(
        "Delete Layer"
    );

    connect(
        addAction,
        &QAction::triggered,
        this,
        &MainWindow::addLayer
    );

    connect(
        deleteAction,
        &QAction::triggered,
        this,
        &MainWindow::deleteLayer
    );
}

void MainWindow::createToolbar()
{
    QToolBar* toolbar = addToolBar(
        "Tools"
    );

    toolbar->setMovable(true);

    QAction* brushAction = toolbar->addAction(
        "Brush"
    );

    QAction* eraserAction = toolbar->addAction(
        "Eraser"
    );

    QAction* colorAction = toolbar->addAction(
        "Color"
    );

    toolbar->addSeparator();

    toolbar->addWidget(
        new QLabel("Size: ", this)
    );

    m_brushSize = new QSpinBox(this);

    m_brushSize->setRange(1, 300);

    m_brushSize->setValue(12);

    toolbar->addWidget(m_brushSize);

    connect(
        brushAction,
        &QAction::triggered,
        this,
        [this]()
        {
            m_canvas->setTool(
                Canvas::Tool::Brush
            );

            statusBar()->showMessage(
                "Brush selected"
            );
        }
    );

    connect(
        eraserAction,
        &QAction::triggered,
        this,
        [this]()
        {
            m_canvas->setTool(
                Canvas::Tool::Eraser
            );

            statusBar()->showMessage(
                "Eraser selected"
            );
        }
    );

    connect(
        colorAction,
        &QAction::triggered,
        this,
        &MainWindow::selectColor
    );

    connect(
        m_brushSize,
        QOverload<int>::of(
            &QSpinBox::valueChanged
        ),
        this,
        [this](int size)
        {
            m_canvas->setBrushSize(size);
        }
    );
}

void MainWindow::createLayerPanel()
{
    QDockWidget* dock = new QDockWidget(
        "Layers",
        this
    );

    dock->setAllowedAreas(
        Qt::LeftDockWidgetArea |
        Qt::RightDockWidgetArea
    );

    m_layerList = new QListWidget(dock);

    dock->setWidget(m_layerList);

    addDockWidget(
        Qt::RightDockWidgetArea,
        dock
    );

    connect(
        m_layerList,
        &QListWidget::currentRowChanged,
        this,
        [this](int row)
        {
            if (row < 0)
            {
                return;
            }

            int index =
                m_document->layerCount() - 1 - row;

            m_document->setActiveLayer(index);
        }
    );
}

void MainWindow::refreshLayers()
{
    m_layerList->clear();

    for (
        int i = m_document->layerCount() - 1;
        i >= 0;
        --i
    )
    {
        const Layer* layer =
            m_document->layer(i);

        if (layer)
        {
            m_layerList->addItem(
                layer->name()
            );
        }
    }

    const int row =
        m_document->layerCount() -
        1 -
        m_document->activeLayerIndex();

    m_layerList->setCurrentRow(row);
}

void MainWindow::newDocument()
{
    bool ok = false;

    int width = QInputDialog::getInt(
        this,
        "New Document",
        "Width:",
        1200,
        1,
        20000,
        1,
        &ok
    );

    if (!ok)
    {
        return;
    }

    int height = QInputDialog::getInt(
        this,
        "New Document",
        "Height:",
        800,
        1,
        20000,
        1,
        &ok
    );

    if (!ok)
    {
        return;
    }

    m_document = std::make_unique<Document>(
        width,
        height
    );

    m_canvas->setDocument(
        m_document.get()
    );

    refreshLayers();

    refreshTitle();
}

void MainWindow::openImage()
{
    QString path = QFileDialog::getOpenFileName(
        this,
        "Open Image",
        QString(),
        "Images (*.png *.jpg *.jpeg *.webp *.bmp)"
    );

    if (path.isEmpty())
    {
        return;
    }

    auto document = std::make_unique<Document>(
        1,
        1
    );

    if (!document->loadImage(path))
    {
        QMessageBox::warning(
            this,
            "Open Error",
            "Cannot open this image."
        );

        return;
    }

    m_document = std::move(document);

    m_canvas->setDocument(
        m_document.get()
    );

    refreshLayers();

    refreshTitle();
}

void MainWindow::saveImage()
{
    QString path = QFileDialog::getSaveFileName(
        this,
        "Export PNG",
        QString(),
        "PNG Image (*.png)"
    );

    if (path.isEmpty())
    {
        return;
    }

    if (!path.endsWith(
        ".png",
        Qt::CaseInsensitive
    ))
    {
        path += ".png";
    }

    if (!m_document->saveImage(path))
    {
        QMessageBox::warning(
            this,
            "Save Error",
            "Cannot save image."
        );

        return;
    }

    statusBar()->showMessage(
        "Image exported successfully",
        3000
    );
}

void MainWindow::addLayer()
{
    QString name = QString(
        "Layer %1"
    ).arg(
        m_document->layerCount() + 1
    );

    m_document->addLayer(name);

    refreshLayers();

    m_canvas->update();
}

void MainWindow::deleteLayer()
{
    int row = m_layerList->currentRow();

    if (row < 0)
    {
        return;
    }

    int index =
        m_document->layerCount() - 1 - row;

    m_document->removeLayer(index);

    refreshLayers();

    m_canvas->update();
}

void MainWindow::selectColor()
{
    QColor color = QColorDialog::getColor(
        m_currentColor,
        this,
        "Select Brush Color"
    );

    if (!color.isValid())
    {
        return;
    }

    m_currentColor = color;

    m_canvas->setBrushColor(color);
}

void MainWindow::refreshTitle()
{
    setWindowTitle(
        "PixelForge 0.1 — Image Editor"
    );
}