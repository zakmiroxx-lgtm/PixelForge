#include <QApplication>
#include <QStyleFactory>

#include "ui/MainWindow.h"

int main(int argc, char* argv[])
{
    QApplication app(argc, argv);

    QApplication::setApplicationName(
        "PixelForge"
    );

    QApplication::setApplicationVersion(
        "0.1.0"
    );

    app.setStyle(
        QStyleFactory::create("Fusion")
    );

    MainWindow window;

    window.show();

    return app.exec();
}