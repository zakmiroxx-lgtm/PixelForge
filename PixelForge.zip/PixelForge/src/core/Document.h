#pragma once

#include "Layer.h"

#include <QImage>
#include <QVector>

#include <memory>

class Document
{
public:
    Document(
        int width,
        int height
    );

    int width() const;

    int height() const;

    int layerCount() const;

    int activeLayerIndex() const;

    Layer* activeLayer();

    const Layer* layer(int index) const;

    void setActiveLayer(int index);

    void addLayer(const QString& name);

    void removeLayer(int index);

    QImage composite() const;

    bool loadImage(const QString& path);

    bool saveImage(const QString& path) const;

private:
    int m_width;

    int m_height;

    QVector<std::shared_ptr<Layer>> m_layers;

    int m_activeLayer = 0;
};