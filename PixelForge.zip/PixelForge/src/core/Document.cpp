#include "Document.h"

#include <QPainter>
#include <QImageReader>
#include <QImageWriter>

Document::Document(
    int width,
    int height
)
    : m_width(width),
      m_height(height)
{
    addLayer("Background");
}

int Document::width() const
{
    return m_width;
}

int Document::height() const
{
    return m_height;
}

int Document::layerCount() const
{
    return static_cast<int>(m_layers.size());
}

int Document::activeLayerIndex() const
{
    return m_activeLayer;
}

Layer* Document::activeLayer()
{
    if (m_activeLayer < 0 ||
        m_activeLayer >= layerCount())
    {
        return nullptr;
    }

    return m_layers[m_activeLayer].get();
}

const Layer* Document::layer(int index) const
{
    if (index < 0 || index >= layerCount())
    {
        return nullptr;
    }

    return m_layers[index].get();
}

void Document::setActiveLayer(int index)
{
    if (index >= 0 && index < layerCount())
    {
        m_activeLayer = index;
    }
}

void Document::addLayer(const QString& name)
{
    auto layer = std::make_shared<Layer>(
        name,
        m_width,
        m_height
    );

    m_layers.push_back(layer);

    m_activeLayer = layerCount() - 1;
}

void Document::removeLayer(int index)
{
    if (layerCount() <= 1)
    {
        return;
    }

    if (index < 0 || index >= layerCount())
    {
        return;
    }

    m_layers.removeAt(index);

    if (m_activeLayer >= layerCount())
    {
        m_activeLayer = layerCount() - 1;
    }
}

QImage Document::composite() const
{
    QImage result(
        m_width,
        m_height,
        QImage::Format_ARGB32_Premultiplied
    );

    result.fill(Qt::transparent);

    QPainter painter(&result);

    for (const auto& layer : m_layers)
    {
        if (!layer->visible())
        {
            continue;
        }

        painter.setOpacity(layer->opacity());

        painter.drawImage(
            0,
            0,
            layer->image()
        );
    }

    painter.end();

    return result;
}

bool Document::loadImage(const QString& path)
{
    QImageReader reader(path);

    reader.setAutoTransform(true);

    QImage image = reader.read();

    if (image.isNull())
    {
        return false;
    }

    m_width = image.width();

    m_height = image.height();

    m_layers.clear();

    addLayer("Imported Image");

    activeLayer()->image() =
        image.convertToFormat(
            QImage::Format_ARGB32_Premultiplied
        );

    return true;
}

bool Document::saveImage(const QString& path) const
{
    QImageWriter writer(
        path,
        "png"
    );

    return writer.write(composite());
}