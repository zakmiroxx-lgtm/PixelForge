#include "Layer.h"

#include <algorithm>

Layer::Layer(
    const QString& name,
    int width,
    int height
)
    : m_name(name)
{
    m_image = QImage(
        width,
        height,
        QImage::Format_ARGB32_Premultiplied
    );

    m_image.fill(Qt::transparent);
}

QString Layer::name() const
{
    return m_name;
}

void Layer::setName(const QString& name)
{
    m_name = name;
}

QImage& Layer::image()
{
    return m_image;
}

const QImage& Layer::image() const
{
    return m_image;
}

bool Layer::visible() const
{
    return m_visible;
}

void Layer::setVisible(bool visible)
{
    m_visible = visible;
}

qreal Layer::opacity() const
{
    return m_opacity;
}

void Layer::setOpacity(qreal opacity)
{
    m_opacity = std::clamp(
        opacity,
        0.0,
        1.0
    );
}